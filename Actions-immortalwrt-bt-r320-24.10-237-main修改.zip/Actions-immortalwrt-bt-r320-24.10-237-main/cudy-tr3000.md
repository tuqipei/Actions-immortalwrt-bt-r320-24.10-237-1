# Cudy TR3000 Immortalwrt 24.10 kernel 6.6 with 237 firmware

![Badge](https://img.shields.io/badge/build-pass-brightgreen?logo=github)

Software

- luci-app-argon-config
- luci-app-autoreboot
- luci-app-diskman
- luci-app-passwall2 (xray only)
- luci-app-ramfree
- luci-app-ttyd
- luci-app-upnp
- luci-app-wol
